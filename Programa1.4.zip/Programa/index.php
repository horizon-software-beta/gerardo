<?php 
//Se inicia la sesion del usuario
session_start();
//Si no se encuentra un id significa que el usuario 
//no esta logiado entonces lo mando a la pagina de 
//inicio de sesion (Sirve para que el usuario no 
//pueda acceder a este archivo por medio de la url)
if (empty($_SESSION["cod_Usuario"])){
    header("location: iniciodesesion.html");
}
?>

<!--Declaramos que va hacer un html5-->
<!DOCTYPE html>
<!--Especifica el idioma natural del contenido de una página web-->
<html lang="en">
<head>
    <!--Significa que pueden usar un solo conjunto de caracteres para las necesidades de varios caracteres-->
    <meta charset="UTF-8">
    <!--El titulo de la pagina web-->
    <title>Cafeteria Horizon</title>
    <!--link de conexion hacia el style-->
    <link rel="stylesheet" href="style/styleS.css">
    <!--Es un api-->
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <!--Implementacion de Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<!--Provee información general (metadatos) acerca del documento, incluyendo su título y enlaces a scripts y 
hojas de estilos-->
</head>

<!--Contienen atributos que controlan la parte visible del documento-->
<body>
    <!--Crea un contenedor para el banner-->
    <div class="banner">
        <!--Crea un contenedor para el navbar-->
        <div class="navbar">
            <!--Logo de la cafeteria-->
            <img src="imagenes/My project-1.png" alt="logo-cafeteria" class="logo">
            <!--Define una lista desordenada-->
            <ul>
                <?php 
                echo $_SESSION['username'];
                ?>
                <!--Se utiliza para hacer referencia al documento de inicio-->
                <li><a href="#">Inicio</a></li>
                <!--Se utiliza para hacer referencia al documento de menu-->
                <li><a href="#">Menú</a></li>

                <a href="login/cerrarsesion.php"> Cerrar sesion </a>
                
            </ul>
        </div>
        <!--Crea un contenedor para el contenido-->
        <div class="contenido">
            <!--Titulo de la pagina principal-->
            <h1>ALGO RICO PARA COMER</h1>
            <!--Es un (subtitulo) que esta por debajo del titulo-->
            <h3>Dale una vuelta a nuestro menu varidado en la parte inferior</h3>
            <h3>Siempre lo mejor encuentra</h4>
            <!--Define las divisiones lógicas existentes en el contenido de una página web-->
        </div>
    </div>
        <!--Slider-->
        <section class="product">
            <!--Titulo de las categorias-->
            <h2 class="pr-category">Productos Que Ofrecemos</h2>
            <!--Sirve principalmente para contener a otros elementos HTML-->
            <div class="pr-container">
                <!--Etiqueta que define las divisiones lógicas existentes en el contenido de una página web-->
                <div class="pr-card">
                    <!--Define las divisiones lógicas existentes en el contenido de una página web-->
                    <div class="pr-image">
                        <!--Imagen de para el catalogo de pizzas -->
                        <img src="imagenes/pizza.jpg" class="product">
                        <!--Boton para acceder al menu del catalogo-->
                        <button class="card-btn">Ver Menú</button>
                    </div>
                    <!--Etiqueta que define las divisiones lógicas existentes en el contenido de una página web-->
                    <div class="pr-info">
                        <!--Titulo del catalogo -->
                        <h2 class="pr-brand">Pizza</h2>
                        <!--Descripcion del catalogo-->
                        <p class="pr-short-des">Pizza hecha de diferentes sabores</p>
                        <!--Precio-->
                        <span class="price">$20</span>
                    </div>
                </div>
                <!--Sirve para crear secciones o agrupar contenidos-->
                <div class="pr-card">
                    <!--Sirve para crear secciones o agrupar contenidos-->
                    <div class="pr-image">
                        <!--Imagen para el catalogo de dulces-->
                        <img src="https://img2.rtve.es/i/?w=1600&i=1628606892247.jpg" class="product">
                        <!--Boton para ver el menu del catalogo-->
                        <button class="card-btn">Ver Menú</button>
                    </div>
                    <!--Sirve para crear secciones o agrupar contenidos-->
                    <div class="pr-info">
                        <!--Titulo del catalogo-->
                        <h2 class="pr-brand">Dulces</h2>
                        <!--Descrision del catalogo-->
                        <p class="pr-short-des">Dulces de Todos Los Tipos</p>
                        <!--Presio-->
                        <span class="price">$35</span>
                    </div>
                </div>
                <!--Sirve para crear secciones o agrupar contenidos-->
                <div class="pr-card">
                    <!--Sirve para crear secciones o agrupar contenidos-->
                    <div class="pr-image">
                        <!--Imagen para el catalogo de bebidas  -->
                        <img src="https://desinformemonos.org/wp-content/uploads/2022/02/bebidas-azucaradas.jpg" class="product">
                        <!--Boton para ver el menu del catalogo-->
                        <button class="card-btn">Ver Menú</button>
                    </div>
                    <!--Sirve para crear secciones o agrupar contenidos-->
                    <div class="pr-info">
                        <!--Titulo del catalogo-->
                        <h2 class="pr-brand">Bebidas</h2>
                        <!--Descripsion del catalogo-->
                        <p class="pr-short-des">Bebidas De Todos Los Tipos </p>
                        <!--Precio-->
                        <span class="price">$15</span>
                    </div>
                </div>
                <!--Sirve para crear secciones o agrupar contenidos-->
                <div class="pr-card">
                    <!--Sirve para crear secciones o agrupar contenidos-->
                    <div class="pr-image">
                        <!--Importacion de la imagen para el catalogo de Helados-->
                        <img src="https://i.blogs.es/098b7c/helados1/1366_2000.jpg" class="product">
                        <!--Boton para acceder al menu del catalogo-->
                        <button class="card-btn">Ver Menú</button>
                    </div>
                    <!--Sirve para crear secciones o agrupar contenidos-->
                    <div class="pr-info">
                        <!--Titulo del catalogo-->
                        <h2 class="pr-brand">Helado </h2>
                        <!--Descripsion del catalogo-->
                        <p class="pr-short-des">Helado tradicional</p>
                        <!--Precio-->
                        <span class="price">$20</span>
                    </div>
                </div>
                    </div>
                </div>
        </section>
    </body>
    </html>