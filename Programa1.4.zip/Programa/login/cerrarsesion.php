<?php // es una entrada para codificar en php

// se inicia la sesion del usuario seleccionado
session_start();

// se destruye la sesion iniciada para que se puedan borrar los datos agregados
session_destroy();
// reubica al usuario al salir de la sesion
header("location: ../Iniciodesesion.html");
(exit);
?>
