<?php
// se inicia la sesion del usuario
session_start();

//Se incluye el codigo donde se realiza la conexion a la base de datos
include("conexion.php");

//Es una condicion para saber si los campos estan vacios o no
if(!empty($_POST["Usuario"]) and !empty($_POST["Contraseña"])){
    //Son los valores que tiene que regresar de la base de datos
    $Usuario=$_POST["Usuario"];
    $Contraseña=$_POST["Contraseña"];
    $Contraseña = hash('sha512', $Contraseña);
    
    //Se seleccionan los valores que se tienen que comparar de la tabla(usuario)
    $sql=$conn->query("SELECT * FROM usuario WHERE Usuario ='$Usuario' and Contraseña='$Contraseña' ");
    //Regresa una condicion en la cual si estan dentro o incluios los redirecciona
    if ($datos=$sql->fetch_object()){
        //Inicia una sesion
        session_start();
         //Almacena el codigo del usuario
        $_SESSION["cod_Usuario"]=$datos->cod_Usuario;
         //Almacena del usuario
        $_SESSION['username']=$Usuario;
        // redirige a una pagina depues de haber iniciado sesion
        header("location: index.php");
    // y si no estan en la base de datos regresa un mensaje de error
    }else {
        header("location: login.php");
        echo "<div>Verifica la contraseña o el correo electronico</div>";
    }
//Regresa un mensaje donde marca si hay datos en esas partes solicitadas
}else {
    echo "campos vacios";
}
?>