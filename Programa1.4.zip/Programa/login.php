<!--Declaramos que va hacer un html5-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!--Titulo de la pestaña de la pagina-->
    <title>Formulario</title>
    <!--Importamos por medio de un link nuestra hoja de estilos-->
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@100&display=swap');
    </style>

    <!--Inicio de sesion---->
    <!--Abrimos una etiqueta para formularios con un metodo POST (POST sirve para enviar el formulario) tambien 
    le asignamos un accion que a la hora de enviar el documento nos mandara al archivo login.php en el que estara 
    el procedimiento para poder iniciar sesion -->
    <form class="form" action="login.php"  name="" method="POST">
        
        <!--TITULO-->
        <h1 class="titulo">Inicio de sesion</h1>
        
        <!--Abrimos un php para importar los archivos de conexion.php y login.php (login/login.php es una ruta para 
        acceder al archivo donde indico la carpeta y el nombre del archivo) esto sirve para poder mostrar los ecos
        de los archivos anteriores y para poder hacer la conexion con la base de datos en este archivo -->
        <?php 
        // se incluyen los archivos (conexion y login) para poder usarlos depues
        include "conexion.php";
        include "login/login.php";

        ?>
        
        <!--Campos del inicio de sesion-->
        <p>usuario</p>
        <input class="cajas" type="text"  name="Usuario" placeholder="Usuario"  >
        <p>Contraseña</p>
        <input class="cajas" type="password" name="Contraseña" placeholder="Contraseña" >
        
        <!--Inpervinculo para poder llevar al usuario al registro-->
        <p>Si no tienes cuenta <a href="registro.html">Registrate aqui</a></p>

        <!--Boton para enviar los datos y iniciar sesion-->
        <input class="btn" type="submit" name="Boton" value="Iniciar sesion"/>

    </form>
    
</body>
</html>