<?php
//Se incluye el codigo donde se realiza la conexion a la base de datos
include("conexion.php");
// se inicia la sesion con los datos registrados
session_start();

//Aqui es donde se regresan los valores solicitados o se (piden)
$NombreCompleto = $_POST["NombreCompleto"] ;
$Usuario = $_POST["Usuario"];
$CorreoElectronico = $_POST["CorreoElectronico"] ;
$Contraseña = $_POST["Contraseña"] ;
$Telefono = $_POST["Telefono"] ;

//Se encripta la contraseña
$Contraseña = hash('sha512', $Contraseña);

//Agregar datos a la tabla (usuario)
$sql = "INSERT INTO usuario (NombreCompleto, Usuario, Contraseña, CorreoElectronico, Telefono )
VALUES ('$NombreCompleto', '$Usuario', '$Contraseña','$CorreoElectronico','$Telefono')";

//Es una condicion donde manda un mensaje en caso de que se hayan agregado correctamente los datos solicitados
if (mysqli_query($conn, $sql)) {
    //Inicia una sesion
    session_start();
    //Almacena el codigo del usuario 
    $_SESSION["cod_Usuario"]=$datos->cod_Usuario;
    //la sesion guarda un valor insertado
    $_SESSION['username']=$Usuario;
    // redirige a una pagina depues de haberte registrado
    header('location: index.php');

//Regresa un mensaje en donde esta el error de sql
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
?>