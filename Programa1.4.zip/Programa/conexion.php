<?php 
//Se definen las entradas para posteriormente conectarse
$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname = "registro";

// Conectarse a la base de datos con los valores añadidos
$conn = mysqli_connect($servername, $username, $password, $dbname);
?>