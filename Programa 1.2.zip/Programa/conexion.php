<?php
// Conectarse a la base de datos
$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname = "registro";

$conn = mysqli_connect($servername, $username, $password, $dbname);
// Verificar la conexión
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}
echo "Conexión exitosa";

$NombreCompleto = $_POST["NombreCompleto"] ;
$CorreoElectronico = $_POST["CorreoElectronico"] ;
$Contraseña = $_POST["Contraseña"] ;
$Telefono = $_POST["Telefono"] ;

$Contraseña = hash('sha512', $Contraseña);

// Agregar datos a la tabla
$sql = "INSERT INTO usuario (NombreCompleto, Contraseña, CorreoElectronico, Telefono )
VALUES ('$NombreCompleto', '$Contraseña','$CorreoElectronico','$Telefono')";

if (mysqli_query($conn, $sql)) {
    echo "Datos agregados correctamente";
    header('location: index.html');
    
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

?>