<?php
//Funcion para conectarse a la base de datos 
//con los parametros host,user y pass para conectarse a la base de datos 
//Junto con el nombre de la base de datos 
//la funcion mysqli_connect establace la coneccion con el servidor de la base de datos
//La duncion mysqli_select_db selecciona la base de datos con la que se quiere acceder 
//Y finamente me devuelve con que seria la coneccion 
function conectar(){
    $host="localhost";
    $user="root";
    $pass="";
    
    $bd="productos";
    
    $con=mysqli_connect($host, $user, $pass);

    mysqli_select_db($con, $bd);

    return $con;
}
?>