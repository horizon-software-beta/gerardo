<?php

// se crea la conexion a el archivo "conexion"
include("conexion.php");
$con=conectar();

// es para marcar por que cosa se identifican y por ese medio se buscan
$cod_Producto=$_GET['id'];

// se crea un select para seleccionar la tabla necesaria y sus valores
$sql="SELECT * FROM producto WHERE cod_Producto ='$cod_Producto'";
$query=mysqli_query($con, $sql);

$row=mysqli_fetch_array($query);
?>

<!--Creo un HTML5-->
<!DOCTYPE html>
<html lang="en">

    <head>
        <!--Titulo-->
        <title>Actualizar</title>
        <!--Me permite presentar cualquier caracter del mundo incluyendo caracteres especiales--> 
        <meta charset="UFF-8">
        <!--Permite que la pantalla se adapte a dispositivos moviles-->
        <meta name="viewport" content="whidth=device-width, initial-scale=1">
        <!--Coenccion con BOOTSTRAP para dar diseño a nustra tabla-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    </head>

    <body>
        <!--Da un margen superior de 5 para separa la caja de texto inicial del la parte superior-->
        <div class="container mt-5">
            <!--From tiene una accion que a la hora de llenar el formulario
            al dar clic al boton este me llevara al documento insertar php,
            y contiene un metodo post que lleva el formulario a la web-->
            <form action="update.php" method="POST">
                <!--Campo de entrada oculto para el susuario el que se encraga de ocultarlo es "hidden" y este campo 
                contendra el codigo del producto  -->
                <input type="hidden" name="cod_Producto" value="<?php echo $row['cod_Producto']?>">

                    <!--Campos que contiene lo que hay en la base de datos-->
                    <input type="text" class="form-control mb-3" name="Nombre" placeholder="Nombre" value="<?php echo $row['Nombre']?>">
                    <input type="text" class="form-control mb-3" name="Precio" placeholder="Precio" value="<?php echo $row['Precio']?>">
                    <input type="text" class="form-control mb-3" name="Unidad" placeholder="Unidad" value="<?php echo $row['Unidad']?>">
                    <input type="text" class="form-control mb-3" name="Existencia" placeholder="Existencia" value="<?php echo $row['Existencia']?>">
                    <input type="text" class="form-control mb-3" name="Costo" placeholder="Costo" value="<?php echo $row['Costo']?>">

                <!--Boton de Actualizar-->
                <input type="submit" class="btn btn-primary btn-block" value="Actualizar">
            </form>
        </div>

    </body>
</html>
