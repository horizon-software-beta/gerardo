<?php
   //Hace la coneccion con la base de datos mediante el documento conexion.php
   include("conexion.php");
   //Conecta la base de datos
   $con=conectar();
   //Consulta a la base de datos y me trae las columnas y filas de la tabla 
   $sql="SELECT *  FROM producto";
   //Genera la consulta en la coneccion y asigna el resultado a query
   $query=mysqli_query($con,$sql);
?>

<!DOCTYPE html>
<!--Especifica el idioma natural del contenido de una página web-->
<html lang="en">
<!--Provee información general-->
    <head>
        <!--Coneccion con Css-->
        <link href="css/style.css" rel="stylesheet">
        <!--Coneccion con Css de Bootstrap-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <!--Coneccion con Css de DataTables-->
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/dt-1.13.1/datatables.min.css"/>
        <!--Especifica la codificación de caracteres del documento-->
        <meta charset="UTF-8">
        <!--le permite al usuario o al navegador establecer el modo de compatibilidad-->
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Sirve para definir qué área de pantalla está disponible al renderizar un documento-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--Titulo de la pagina-->
        <title>Productos</title>
        <!-- Define una hoja de estilos conectada-->
        <link rel="stylesheet" href="style.css"/>
    
    </head>

    <!--Cuerpo de nustra pagina
    contienen atributos que controlan la parte visible del documento-->
    <body>
        <!--La clase nos separa un poco de la parte superior como a los lados -->
        <div class="container mt-5">
            <!--Divide la pagina en 2 partes row registro y la tabla -->
            <div class="row">
                <!--La caja de texto tendra un ancho de 3-->
                <div class="col-md-3">
                    <!--Titulo de nustro registro -->
                    <h1>Datos del Producto </h1>

                    <!--Formulario-->

                    <!--From tiene una accion que a la hora de llenar el formulario
                    al dar clic al boton este me llevara al documento insertar php,
                    y contiene un metodo post que lleva el formulario a la web-->
                    <form action="insertar.php" method="POST">
                        <!--input son los campos a llenar, 
                            type es el tipo que sera text
                            le asignamos clases que seran las que modifican a los campos con un tamaño de 3,
                            name son los identificadores de la base de datos 
                            placeholder es lo que nos indica el campo para llenarlo-->
                        <input type="text" class="form-control mb-3" name="Nombre" placeholder="nombre">
                        <input type="text" class="form-control mb-3" name="Precio" placeholder="precio">
                        <input type="text" class="form-control mb-3" name="Unidad" placeholder="unidad">
                        <input type="text" class="form-control mb-3" name="Existencia" placeholder="existencia">
                        <input type="text" class="form-control mb-3" name="Costo" placeholder="costo">

                        <!--Boton para enviar el registro-->
                        <!--El boton es de tipo submit para poder enviar los datos del formulario al documento insetar php
                        este se utiliza junto al metodo POST y tiene una clase mi boton primary que torna a mi boton de 
                        un color azul claro-->
                        <input type="submit" class="btn btn-primary">

                    </form>

                </div>
                <!--Donde me muestra las tablas va a tener un ancho de 8-->
                <div class="col-md-8">
                    <!--Creamos la tabla con la clase del mismo nombre para que
                    tome forma de esta y un margen superior de 3 para separar la tabla de la caja de busqueda  -->
                    <table class="table mt-3" id="tabla">
                        <!--Encabezado de la fila donde estaran nustros campos-->
                        <thead class="table-success table-striped">
                            <tr>
                                <!--Cuerpo de nuestra tabla-->
                                <!--th aparte de servir para los campos tambien sirve para dar 
                                continuacion con nustra linea verde en nustra tabla cada th agranda 
                                la barra de color verde-->
                                <th>cod_Producto</th>
                                <th>Nombre</th>
                                <th>Precio</th>
                                <th>Unidad</th>
                                <th>Existencia</th>
                                <th>Costo</th>
                                <th></th>
                                <th></th>
                                
                            </tr>
                        </thead>

                        <!--Cuerpo de la tabla-->
                        <tbody>
                            <!--Me agrega lo que hay de la base de datos lo agrega a la 
                            tabla en sus apartados correspondientes-->
                                <?php
                                //esta condicion lo que hace es hacer hacer un bucle que recorre todo los registros devueltos 
                                //por la consula, asignando cada registro a la variable "row y me los muestra en la tabla"
                                    while($row=mysqli_fetch_array($query)){
                                ?>
                                    <tr>
                                        <!--th indica que se trata de unacelda en mi tabla y el codigo php echo row agarra el valor que tengo 
                                        en la  base de datos que seria cod_Productos y lo imprime en la tabla -->
                                        <th><?php echo $row['cod_Producto']?></th>
                                        <th><?php echo $row['Nombre']?></th>
                                        <th><?php echo $row['Precio']?></th>
                                        <th><?php echo $row['Unidad']?></th>
                                        <th><?php echo $row['Existencia']?></th>
                                        <th><?php echo $row['Costo']?></th>

                                        <!--Boton para editar la tabla-->
                                        <!-- Se crea un enlace en la celda del emcabezado que me redirije al documento actualizar php con el idenificador 
                                        cod_Producto-->
                                        <th> <a href="actualizar.php?id=<?php echo $row['cod_Producto'] ?>" class="btn btn-info">Editar</a></th>

                                        <!--Boton para eliminar un registro de la tabla-->
                                        <!--Se crea un enlace en la celda que me redirije al documento delete php con el idenificador 
                                        cod_Producto captura por medio de este se captura el  alimentos y lo puede eliminar eliminar -->
                                        <th><a href="delete.php?id=<?php echo $row['cod_Producto'] ?>" class="btn btn-danger">Eliminar></a></th>
                                    </tr>
                                <?php
                                    }
                                ?>
                            
                        </tbody>

                    </table>
                    

                </div>

            </div>

        </div>
        
         
        <!--Importamos la biblioteca de JavaScript Jquery-->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
        <!--Importa la biblioteca de DataTables agrega la funcion de busqueda, ordenamiento, paginacion y filtrado--> 
        <script type="text/javascript" src="https://cdn.datatables.net/v/bs5/dt-1.13.1/datatables.min.js"></script>

        
        <script>
        //Por medio del id de la tabla le agrega varias funcionalidades 
        var table = new DataTable('#tabla', {
        language: {
                //Configura el idioma de la DataTable a español
                url: 'https://cdn.datatables.net/plug-ins/1.13.4/i18n/es-MX.json',
          },
        });
        </script>
    </body>        
</html>