<?php

// se crea una conexion a la conexion hacia la base de datos
// esto es necesario ya que de no conectarse no se puede realizar algun cambio
include("conexion.php");
$con=conectar();

// se definen las columnas para poder modificarlas
$Nombre=$_POST['Nombre'];
$Precio=$_POST['Precio'];
$Unidad=$_POST['Unidad'];
$Existencia=$_POST['Existencia'];
$Costo=$_POST['Costo'];

// se crea un query que lo que hace es añadir datos a las columnas de una tabla por mediante de valores 
//Se agregan las columnas de la tabla de producto de la base de datos y despues los valores que queremos insertar
$sql=" INSERT INTO producto (Nombre, Precio, Unidad, Existencia, Costo) values('$Nombre', '$Precio', '$Unidad', '$Existencia', '$Costo')";
$query=mysqli_query($con, $sql);

// es la direccion de la cual se realizara la operacion
if($query){
    header("location: alumno.php");

}else{
}
?>