<?php
   //Hace la coneccion con la base de datos mediante el documento conexion.php
   include("conexion.php");
   //Conecta la base de datos
   $con=conectar();
   //Consulta a la base de datos y me trae las columnas y filas de la tabla 
   $sql="SELECT *  FROM usuario";
   //Genera la consulta en la coneccion y asigna el resultado a query
   $query=mysqli_query($con,$sql);
?>

<!DOCTYPE html>
<!--Especifica el idioma natural del contenido de una página web-->
<html lang="en">
<!--Provee información general-->
    <head>
        <!--Coneccion con Css-->
        <link href="css/style.css" rel="stylesheet">
        <!--Coneccion con Css de Bootstrap-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <!--Coneccion con Css de DataTables-->
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/dt-1.13.1/datatables.min.css"/>
        <!--Especifica la codificación de caracteres del documento-->
        <meta charset="UTF-8">
        <!--le permite al usuario o al navegador establecer el modo de compatibilidad-->
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Sirve para definir qué área de pantalla está disponible al renderizar un documento-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--Titulo de la pagina-->
        <title>Personal</title>
        <!-- Define una hoja de estilos conectada-->
        <link rel="stylesheet" href="style.css"/>
    
    </head>

    <!--Cuerpo de nustra pagina
    contienen atributos que controlan la parte visible del documento-->
    <body>
        <!--La clase nos separa un poco de la parte superior como a los lados -->
        <div class="container mt-5">
            <!--Divide la pagina en 2 partes row registro y la tabla -->
            <div class="row">
                <!--La caja de texto tendra un ancho de 3-->
                <div class="col-md-3">
                    <!--Titulo de nustro registro -->
                    <h1>Datos del Personal </h1>

                    <!--Formulario-->

                    <!--From tiene una accion que a la hora de llenar el formulario
                    al dar clic al boton este me llevara al documento insertar php,
                    y contiene un metodo post que lleva el formulario a la web-->
                    <form action="insertar.php" method="POST">
                        <!--input son los campos a llenar, 
                            type es el tipo que sera text tambien hay tipo email, password y date,
                            le asignamos clases que seran las que modifican a los campos con un tamaño de 3,
                            name son los identificadores de la base de datos 
                            placeholder es lo que nos indica el campo para llenarlo-->
                        <input type="text" class="form-control mb-3" name="ApellidoP" placeholder="Apellido Paterno">
                        <input type="text" class="form-control mb-3" name="ApellidoM" placeholder="Apellido Materno">
                        <input type="text" class="form-control mb-3" name="Nombre" placeholder="Nombre (s)">
                        <input type="text" class="form-control mb-3" name="Usuario" placeholder="Usuario">
                        <input type="email" class="form-control mb-3" name="Email" placeholder="Correo Electronico">
                        <input type="password" class="form-control mb-3" name="Contraseña" placeholder="Contraseña">
                        <input type="date" class="form-control mb-3" name="Fecha" placeholder="Fecha">
                        <input type="text" class="form-control mb-3" name="Telefono" placeholder="Telefono">
                        <input type="text" class="form-control mb-3" name="Estado" placeholder="Estado">
                        <input type="text" class="form-control mb-3" name="Municipio" placeholder="Municipio">



                        <!--Boton para enviar el registro-->
                        <!--El boton es de tipo submit para poder enviar los datos del formulario al documento insetar php
                        este se utiliza junto al metodo POST y tiene una clase mi boton primary que torna a mi boton de 
                        un color azul claro-->
                        <input type="submit" class="btn btn-primary">

                    </form>

                </div>
                <!--Donde me muestra las tablas va a tener un ancho de 8-->
                <div class="col-md-8">
                    <!--Creamos la tabla con la clase del mismo nombre para que
                    tome forma de esta,un margen superior de 3 
                    le asignamos un id para que el link de javaScript le de unas funcionalidades extras a la tabla-->
                    <table class="table mt-3" id="tablaP">
                        <!--Encabezado de la fila donde estaran nustros campos-->
                        <thead class="table-success table-striped">
                            <tr>
                                <!--Cuerpo de nuestra tabla-->
                                <!--th aparte de servir para los campos tambien sirve para dar 
                                continuacion con nustra linea verde en nustra tabla cada th agranda 
                                la barra de color verde-->
                                <th>Id</th>
                                <th>Apellido Paterno</th>
                                <th>Apellido Materno</th>
                                <th>Nombre (s)</th>
                                <th>Usuario</th>
                                <th>Correo Electronico</th>
                                <th>Contraseña</th>
                                <th>Fecha</th>
                                <th>Telefono</th>
                                <th>Estado</th>
                                <th>Municipio</th>
                                <th></th>
                                <th></th>
                                
                            </tr>
                        </thead>

                        <!--Cuerpo de la tabla-->
                        <tbody>
                            <!--Me agrega lo que hay de la base de datos lo agrega a la 
                            tabla en sus apartados correspondientes-->
                                <?php
                                //esta condicion lo que hace es hacer hacer un bucle que recorre todo los registros devueltos 
                                //por la consula, asignando cada registro a la variable "row y me los muestra en la tabla"
                                    while($row=mysqli_fetch_array($query)){
                                ?>
                                    <tr>
                                        <!--th indica que se trata de una celda en mi tabla y el codigo php echo row agarra el valor que tengo 
                                        en la base de datos que seria cod_Usuario y lo imprime en la tabla -->
                                        <th><?php echo $row['cod_Usuario']?></th>
                                        <th><?php echo $row['ApellidoP']?></th>
                                        <th><?php echo $row['ApellidoM']?></th>
                                        <th><?php echo $row['Nombre']?></th>
                                        <th><?php echo $row['Usuario']?></th>
                                        <th><?php echo $row['Email']?></th>
                                        <th><?php echo $row['Contraseña']?></th>
                                        <th><?php echo $row['Fecha']?></th>
                                        <th><?php echo $row['Telefono']?></th>
                                        <th><?php echo $row['Estado']?></th>
                                        <th><?php echo $row['Municipio']?></th>

                                        <!--Boton para editar la tabla-->
                                        <!-- Se crea un enlace en la celda del emcabezado que me redirije al documento actualizar php con el idenificador 
                                        cod_Usuario-->
                                        <th> <a href="actualizar.php?id=<?php echo $row['cod_Usuario'] ?>" class="btn btn-info">Editar</a></th>

                                        <!--Boton para eliminar un registro de la tabla-->
                                        <!--Se crea un enlace en la celda que me redirije al documento delete php con el idenificador 
                                        cod_Usuario por medio del enlace y codigo php captura el identificador y lo puede eliminar  -->
                                        <th><a href="delete.php?id=<?php echo $row['cod_Usuario'] ?>" class="btn btn-danger">Eliminar></a></th>
                                    </tr>
                                <?php
                                    }
                                ?>
                            
                        </tbody>

                    </table>
                    

                </div>

            </div>

        </div>
        
         
        <!--Importamos la biblioteca de JavaScript Jquery-->
        <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
        <!--Importa la biblioteca de DataTables agrega la funcion de busqueda, ordenamiento, paginacion y filtrado--> 
        <script type="text/javascript" src="https://cdn.datatables.net/v/bs5/dt-1.13.1/datatables.min.js"></script>

        
        <script>
        //Por medio del id de la tabla le agrega varias funcionalidades 
        var table = new DataTable('#tablaP', {
        language: {
                //Configura el idioma de la DataTable a español
                url: 'https://cdn.datatables.net/plug-ins/1.13.4/i18n/es-MX.json',
          },
        });
        </script>
    </body>        
</html>