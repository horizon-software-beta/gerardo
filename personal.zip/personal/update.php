<?php

// se crea una conexion a el archivo "conexion" para poder acceder a la base de datos
include("conexion.php");
$con=conectar();

// se definen las columnas para poder actualizarlas
//Se escriben igual como estan en la base de datos
$cod_Usuario=$_POST['cod_Usuario'];
$ApellidoP=$_POST['ApellidoP'];
$ApellidoM=$_POST['ApellidoM'];
$Nombre=$_POST['Nombre'];
$Usuario=$_POST['Usuario'];
$Email=$_POST['Email'];
$Contraseña=$_POST['Contraseña'];
$Fecha=$_POST['Fecha'];
$Telefono=$_POST['Telefono'];
$Estado=$_POST['Estado'];
$Municipio=$_POST['Municipio'];

// la operacion que se busca realizar es modificar los valores que ya tiene un registro
$sql="UPDATE usuario SET cod_Usuario='$cod_Usuario', ApellidoP='$ApellidoP', ApellidoM='$ApellidoM', Nombre='$Nombre', Usuario='$Usuario', Email='$Email', Contraseña='$Contraseña', Fecha='$Fecha', Telefono='$Telefono' , Estado='$Estado' , Municipio='$Municipio' WHERE cod_Usuario='$cod_Usuario'";
$query=mysqli_query($con, $sql);

    // se crea el lugar a donde tiene que modificar
    if($query){
        Header("Location: personal.php");
    }
?>