<?php
// se crea la conexion a el archivo de "conexion" para poder realizar cambios en la base de datos
include("conexion.php");
// se define "con" como "conectar"
$con=conectar();

// se realiza la conexion a la tabla y columna, por medio del id se elimina el dato 
//el id lo toma del boton de eliminar
$cod_Usuario=$_GET['id'];

// se crea un query que realiza una eliminacion a un dato en la base de datos
$sql="DELETE FROM usuario WHERE cod_Usuario ='$cod_Usuario'";
$query=mysqli_query($con, $sql);

    // es la direccion de la cual va a realizar la operacion
    if($query){
        Header("location: personal.php");
    }
?>