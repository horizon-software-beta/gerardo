<?php
// se crea una conexion a el archivo "conexion" para poder acceder a la base de datos
// esto es necesario ya que de no conectarse no se puede realizar algun cambio
include("conexion.php");
$con=conectar();

// se definen las columnas para poder modificarlas
//Se escriben igual como estan en la base de datos
$ApellidoP=$_POST['ApellidoP'];
$ApellidoM=$_POST['ApellidoM'];
$Nombre=$_POST['Nombre'];
$Usuario=$_POST['Usuario'];
$Email=$_POST['Email'];
$Contraseña=$_POST['Contraseña'];
$Fecha=$_POST['Fecha'];
$Telefono=$_POST['Telefono'];
$Estado=$_POST['Estado'];
$Municipio=$_POST['Municipio'];

// se crea un query que lo que hace es añadir datos a las columnas de una tabla por mediante de valores 
//Se agregan las columnas de la tabla de producto de la base de datos y despues los valores que queremos insertar
$sql=" INSERT INTO usuario (ApellidoP, ApellidoM, Nombre, Usuario, Email, Contraseña, Fecha, Telefono, Estado, Municipio ) values('$ApellidoP', '$ApellidoM', '$Nombre', '$Usuario', '$Email', '$Contraseña', '$Fecha', '$Telefono', '$Estado', '$Municipio')";
$query=mysqli_query($con, $sql);

// es la direccion de la cual se realizara la operacion
if($query){
    header("location: personal.php");

}else{
}
?>