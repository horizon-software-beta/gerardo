<?php

// se crea la conexion a el archivo "conexion"
include("conexion.php");
$con=conectar();

//es para marcar el identificadior y por ese medio se busca
$cod_Usuario=$_GET['id'];

// se crea un select para seleccionar la tabla necesaria y sus valores
$sql="SELECT * FROM usuario WHERE cod_Usuario ='$cod_Usuario'";
$query=mysqli_query($con, $sql);

$row=mysqli_fetch_array($query);
?>

<!--Creo un HTML5-->
<!DOCTYPE html>
<html lang="en">

    <head>
        <!--Titulo-->
        <title>Actualizar</title>
        <!--Me permite presentar cualquier caracter del mundo incluyendo caracteres especiales--> 
        <meta charset="UFF-8">
        <!--Permite que la pantalla se adapte a dispositivos moviles-->
        <meta name="viewport" content="whidth=device-width, initial-scale=1">
        <!--Coenccion con BOOTSTRAP para dar diseño a nustra tabla-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    </head>

    <body>
        <!--Da un margen superior de 5 para separa la caja de texto inicial del la parte superior-->
        <div class="container mt-5">
            <!--From tiene una accion que a la hora de llenar el formulario
            al dar clic al boton este me llevara al documento insert php,
            y contiene un metodo post que lleva el formulario a la web-->
            <form action="update.php" method="POST">
                <!--Campo de entrada oculto para el susuario, el que se encraga de ocultarlo es "hidden" y este campo 
                contendra el codigo del producto-->
                <input type="hidden" name="cod_Usuario" value="<?php echo $row['cod_Usuario']?>">

                    <!--Campos que contiene lo que hay en la base de datos-->
                    <input type="text" class="form-control mb-3" name="ApellidoP" placeholder="Apellido Paterno" value="<?php echo $row['ApellidoP']?>">
                    <input type="text" class="form-control mb-3" name="ApellidoM" placeholder="Apellido Materno" value="<?php echo $row['ApellidoM']?>">
                    <input type="text" class="form-control mb-3" name="Nombre" placeholder="Nombre" value="<?php echo $row['Nombre']?>">
                    <input type="text" class="form-control mb-3" name="Usuario" placeholder="Usuario" value="<?php echo $row['Usuario']?>">
                    <input type="email" class="form-control mb-3" name="Email" placeholder="Email" value="<?php echo $row['Email']?>">
                    <input type="password" class="form-control mb-3" name="Contraseña" placeholder="Contraseña" value="<?php echo $row['Contraseña']?>">
                    <input type="date" class="form-control mb-3" name="Fecha" placeholder="Fecha" value="<?php echo $row['Fecha']?>">
                    <input type="tel" class="form-control mb-3" name="Telefono" placeholder="Telefono" value="<?php echo $row['Telefono']?>">
                    <input type="text" class="form-control mb-3" name="Estado" placeholder="Estado" value="<?php echo $row['Estado']?>">
                    <input type="text" class="form-control mb-3" name="Municipio" placeholder="Municipio" value="<?php echo $row['Municipio']?>">

                <!--Boton de Actualizar-->
                <input type="submit" class="btn btn-primary btn-block" value="Actualizar">
            </form>
        </div>

    </body>
</html>
